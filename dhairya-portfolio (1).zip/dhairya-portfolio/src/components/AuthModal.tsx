import { useState } from 'react';
import { X } from 'lucide-react';

type AuthMode = 'login' | 'signup';

interface User {
  email: string;
  role: 'user' | 'admin';
}

export function AuthModal({ onClose, onAuth, isDark }: { onClose: () => void; onAuth: (user: User) => void; isDark: boolean }) {
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const user: User = {
      email,
      role: email === 'admin@example.com' ? 'admin' : 'user',
    };

    onAuth(user);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-6">
      <div className={`${isDark ? 'bg-slate-900' : 'bg-white'} rounded-3xl p-8 max-w-md w-full relative`}>
        <button
          onClick={onClose}
          className={`absolute top-6 right-6 p-2 rounded-lg transition-all ${isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'}`}
        >
          <X size={20} />
        </button>

        <h2 className={`text-3xl font-bold mb-6 ${isDark ? 'text-white' : 'text-slate-900'}`}>
          {mode === 'login' ? 'Sign In' : 'Create Account'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required={mode === 'signup'}
                className={`w-full px-4 py-3 rounded-xl transition-all ${
                  isDark
                    ? 'bg-slate-800 border border-slate-700 text-white focus:border-blue-500'
                    : 'bg-white border border-slate-200 text-slate-900 focus:border-blue-500'
                } focus:outline-none focus:ring-2 focus:ring-blue-500/20`}
                placeholder="Your name"
              />
            </div>
          )}

          <div>
            <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className={`w-full px-4 py-3 rounded-xl transition-all ${
                isDark
                  ? 'bg-slate-800 border border-slate-700 text-white focus:border-blue-500'
                  : 'bg-white border border-slate-200 text-slate-900 focus:border-blue-500'
              } focus:outline-none focus:ring-2 focus:ring-blue-500/20`}
              placeholder="you@example.com"
            />
          </div>

          <div>
            <label className={`block text-sm font-medium mb-2 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className={`w-full px-4 py-3 rounded-xl transition-all ${
                isDark
                  ? 'bg-slate-800 border border-slate-700 text-white focus:border-blue-500'
                  : 'bg-white border border-slate-200 text-slate-900 focus:border-blue-500'
              } focus:outline-none focus:ring-2 focus:ring-blue-500/20`}
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl font-semibold transition-all bg-blue-600 hover:bg-blue-500 text-white"
          >
            {mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
            className={`text-sm ${isDark ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'}`}
          >
            {mode === 'login' ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
          </button>
        </div>

        <div className={`mt-6 p-4 rounded-xl ${isDark ? 'bg-slate-800' : 'bg-slate-50'}`}>
          <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
            <strong>Demo credentials:</strong>
            <br />
            Admin: admin@example.com / any password
            <br />
            User: any other email / any password
          </p>
        </div>
      </div>
    </div>
  );
}
