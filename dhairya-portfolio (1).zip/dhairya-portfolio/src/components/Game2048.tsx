import { useState, useEffect, useCallback } from 'react';
import { RotateCcw } from 'lucide-react';

type Tile = {
  value: number;
  id: string;
};

type Board = (Tile | null)[][];

const GRID_SIZE = 4;

export function Game2048({ onClose, isDark }: { onClose: () => void; isDark: boolean }) {
  const [board, setBoard] = useState<Board>([]);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [hasWon, setHasWon] = useState(false);

  const createEmptyBoard = (): Board => {
    return Array(GRID_SIZE)
      .fill(null)
      .map(() => Array(GRID_SIZE).fill(null));
  };

  const addRandomTile = (currentBoard: Board): Board => {
    const newBoard = currentBoard.map((row) => [...row]);
    const emptyCells: { row: number; col: number }[] = [];

    for (let row = 0; row < GRID_SIZE; row++) {
      for (let col = 0; col < GRID_SIZE; col++) {
        if (!newBoard[row][col]) {
          emptyCells.push({ row, col });
        }
      }
    }

    if (emptyCells.length > 0) {
      const { row, col } = emptyCells[Math.floor(Math.random() * emptyCells.length)];
      newBoard[row][col] = {
        value: Math.random() < 0.9 ? 2 : 4,
        id: `${Date.now()}-${row}-${col}`,
      };
    }

    return newBoard;
  };

  const initializeGame = () => {
    let newBoard = createEmptyBoard();
    newBoard = addRandomTile(newBoard);
    newBoard = addRandomTile(newBoard);
    setBoard(newBoard);
    setScore(0);
    setGameOver(false);
    setHasWon(false);
  };

  useEffect(() => {
    initializeGame();
  }, []);

  const moveTiles = useCallback(
    (direction: 'up' | 'down' | 'left' | 'right') => {
      if (gameOver) return;

      let newBoard = board.map((row) => [...row]);
      let moved = false;
      let newScore = score;

      const moveRow = (row: (Tile | null)[]): (Tile | null)[] => {
        const filtered = row.filter((tile) => tile !== null);
        const merged: (Tile | null)[] = [];

        for (let i = 0; i < filtered.length; i++) {
          if (i < filtered.length - 1 && filtered[i]!.value === filtered[i + 1]!.value) {
            const mergedValue = filtered[i]!.value * 2;
            merged.push({
              value: mergedValue,
              id: `${Date.now()}-merged-${i}`,
            });
            newScore += mergedValue;
            if (mergedValue === 2048 && !hasWon) {
              setHasWon(true);
            }
            i++;
          } else {
            merged.push(filtered[i]);
          }
        }

        while (merged.length < GRID_SIZE) {
          merged.push(null);
        }

        return merged;
      };

      if (direction === 'left') {
        for (let row = 0; row < GRID_SIZE; row++) {
          const oldRow = [...newBoard[row]];
          newBoard[row] = moveRow(newBoard[row]);
          if (JSON.stringify(oldRow) !== JSON.stringify(newBoard[row])) moved = true;
        }
      } else if (direction === 'right') {
        for (let row = 0; row < GRID_SIZE; row++) {
          const oldRow = [...newBoard[row]];
          newBoard[row] = moveRow([...newBoard[row]].reverse()).reverse();
          if (JSON.stringify(oldRow) !== JSON.stringify(newBoard[row])) moved = true;
        }
      } else if (direction === 'up') {
        for (let col = 0; col < GRID_SIZE; col++) {
          const column = newBoard.map((row) => row[col]);
          const oldColumn = [...column];
          const movedColumn = moveRow(column);
          if (JSON.stringify(oldColumn) !== JSON.stringify(movedColumn)) moved = true;
          for (let row = 0; row < GRID_SIZE; row++) {
            newBoard[row][col] = movedColumn[row];
          }
        }
      } else if (direction === 'down') {
        for (let col = 0; col < GRID_SIZE; col++) {
          const column = newBoard.map((row) => row[col]);
          const oldColumn = [...column];
          const movedColumn = moveRow([...column].reverse()).reverse();
          if (JSON.stringify(oldColumn) !== JSON.stringify(movedColumn)) moved = true;
          for (let row = 0; row < GRID_SIZE; row++) {
            newBoard[row][col] = movedColumn[row];
          }
        }
      }

      if (moved) {
        newBoard = addRandomTile(newBoard);
        setBoard(newBoard);
        setScore(newScore);

        const hasEmpty = newBoard.some((row) => row.some((cell) => cell === null));
        if (!hasEmpty && !canMove(newBoard)) {
          setGameOver(true);
        }
      }
    },
    [board, score, gameOver, hasWon]
  );

  const canMove = (currentBoard: Board): boolean => {
    for (let row = 0; row < GRID_SIZE; row++) {
      for (let col = 0; col < GRID_SIZE; col++) {
        const current = currentBoard[row][col];
        if (!current) continue;

        if (col < GRID_SIZE - 1 && currentBoard[row][col + 1]?.value === current.value) return true;
        if (row < GRID_SIZE - 1 && currentBoard[row + 1][col]?.value === current.value) return true;
      }
    }
    return false;
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'w', 'a', 's', 'd'].includes(key)) {
        e.preventDefault();
      }

      if (key === 'arrowup' || key === 'w') moveTiles('up');
      else if (key === 'arrowdown' || key === 's') moveTiles('down');
      else if (key === 'arrowleft' || key === 'a') moveTiles('left');
      else if (key === 'arrowright' || key === 'd') moveTiles('right');
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [moveTiles]);

  const getTileColor = (value: number) => {
    const colors: { [key: number]: string } = {
      2: isDark ? 'bg-blue-900 text-blue-100' : 'bg-blue-100 text-blue-900',
      4: isDark ? 'bg-blue-800 text-blue-100' : 'bg-blue-200 text-blue-900',
      8: isDark ? 'bg-cyan-700 text-cyan-100' : 'bg-cyan-300 text-cyan-900',
      16: isDark ? 'bg-cyan-600 text-cyan-100' : 'bg-cyan-400 text-cyan-900',
      32: isDark ? 'bg-teal-600 text-teal-100' : 'bg-teal-400 text-teal-900',
      64: isDark ? 'bg-green-600 text-green-100' : 'bg-green-500 text-white',
      128: isDark ? 'bg-yellow-600 text-yellow-100' : 'bg-yellow-400 text-yellow-900',
      256: isDark ? 'bg-orange-600 text-orange-100' : 'bg-orange-500 text-white',
      512: isDark ? 'bg-red-600 text-red-100' : 'bg-red-500 text-white',
      1024: isDark ? 'bg-purple-600 text-purple-100' : 'bg-purple-500 text-white',
      2048: isDark ? 'bg-pink-600 text-pink-100' : 'bg-pink-500 text-white',
    };
    return colors[value] || (isDark ? 'bg-slate-600 text-slate-100' : 'bg-slate-800 text-white');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-6">
      <div className={`${isDark ? 'bg-slate-900' : 'bg-white'} rounded-3xl p-8 max-w-2xl w-full`}>
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>2048 Game</h2>
            <p className={`text-lg mt-2 ${isDark ? 'text-blue-400' : 'text-blue-600'}`}>Score: {score}</p>
          </div>
          <button
            onClick={onClose}
            className={`px-4 py-2 rounded-xl font-medium transition-all ${isDark ? 'bg-slate-800 hover:bg-slate-700 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-900'}`}
          >
            Close
          </button>
        </div>

        <div className="flex justify-center mb-6">
          <div
            className={`grid grid-cols-4 gap-3 p-4 rounded-2xl ${isDark ? 'bg-slate-800' : 'bg-slate-200'}`}
            style={{ width: 'fit-content' }}
          >
            {board.map((row, rowIndex) =>
              row.map((tile, colIndex) => (
                <div
                  key={`${rowIndex}-${colIndex}`}
                  className={`w-20 h-20 rounded-xl flex items-center justify-center text-2xl font-bold transition-all duration-150 ${
                    tile
                      ? `${getTileColor(tile.value)} transform scale-100`
                      : isDark
                      ? 'bg-slate-700'
                      : 'bg-slate-100'
                  }`}
                >
                  {tile?.value || ''}
                </div>
              ))
            )}
          </div>
        </div>

        {gameOver && (
          <div className="text-center mb-6">
            <p className={`text-xl font-bold mb-4 ${isDark ? 'text-red-400' : 'text-red-600'}`}>Game Over!</p>
            <button
              onClick={initializeGame}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-medium bg-blue-600 hover:bg-blue-500 text-white transition-all"
            >
              <RotateCcw size={20} />
              Play Again
            </button>
          </div>
        )}

        {hasWon && !gameOver && (
          <div className="text-center mb-6">
            <p className={`text-xl font-bold ${isDark ? 'text-green-400' : 'text-green-600'}`}>
              You reached 2048! 🎉
            </p>
          </div>
        )}

        <div className={`text-center text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
          <p>Use Arrow Keys or WASD to move tiles</p>
          <p className="mt-1">Combine tiles to reach 2048!</p>
        </div>
      </div>
    </div>
  );
}
