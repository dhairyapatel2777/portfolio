/*
  # Create contact messages table

  ## Overview
  This migration creates a table to store contact form submissions from the portfolio website.
  All messages are securely stored with timestamps and email validation.

  ## New Tables
  - `contact_messages`
    - `id` (uuid, primary key) - Unique identifier for each message
    - `name` (text, required) - Name of the person contacting
    - `email` (text, required) - Email address for follow-up communication
    - `message` (text, required) - The actual message content
    - `created_at` (timestamptz) - Timestamp when the message was submitted
    - `read` (boolean) - Flag to track if the message has been read

  ## Security
  - Enable RLS (Row Level Security) on the contact_messages table
  - Add policy allowing anyone to insert messages (for public contact form)
  - Add policy allowing authenticated admin users to read all messages
  
  ## Notes
  - Messages are publicly insertable to allow contact form submissions
  - Only authenticated users (admins) can view messages
  - The read flag helps track which messages have been reviewed
*/

-- Create contact_messages table
CREATE TABLE IF NOT EXISTS contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  message text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;

-- Policy: Allow anyone to insert contact messages (public form submission)
CREATE POLICY "Anyone can submit contact messages"
  ON contact_messages
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Policy: Allow authenticated users to view all messages (for admin dashboard)
CREATE POLICY "Authenticated users can view all messages"
  ON contact_messages
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy: Allow authenticated users to update message read status
CREATE POLICY "Authenticated users can update message status"
  ON contact_messages
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create index for faster queries by creation date
CREATE INDEX IF NOT EXISTS contact_messages_created_at_idx ON contact_messages(created_at DESC);

-- Create index for filtering read/unread messages
CREATE INDEX IF NOT EXISTS contact_messages_read_idx ON contact_messages(read);
