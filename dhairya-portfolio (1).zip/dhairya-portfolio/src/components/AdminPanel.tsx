import { useState } from 'react';
import { X, Plus, Trash2, Eye, EyeOff } from 'lucide-react';

interface AdminPanelProps {
  onClose: () => void;
  isDark: boolean;
}

export function AdminPanel({ onClose, isDark }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'skills' | 'projects' | 'visibility'>('skills');
  const [newSkill, setNewSkill] = useState('');
  const [newProject, setNewProject] = useState({ title: '', description: '', tech: '' });

  const [skills, setSkills] = useState<string[]>([
    'React', 'TypeScript', 'Node.js', 'PostgreSQL'
  ]);

  const [projects, setProjects] = useState([
    { id: 1, title: 'Movie Recommender', visible: true },
    { id: 2, title: '2048 Game', visible: true }
  ]);

  const [sections, setSections] = useState([
    { id: 'about', name: 'About', visible: true },
    { id: 'projects', name: 'Projects', visible: true },
    { id: 'skills', name: 'Skills', visible: true },
    { id: 'contact', name: 'Contact', visible: true }
  ]);

  const handleAddSkill = () => {
    if (newSkill.trim()) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (index: number) => {
    setSkills(skills.filter((_, i) => i !== index));
  };

  const toggleProjectVisibility = (id: number) => {
    setProjects(projects.map(p => p.id === id ? { ...p, visible: !p.visible } : p));
  };

  const toggleSectionVisibility = (id: string) => {
    setSections(sections.map(s => s.id === id ? { ...s, visible: !s.visible } : s));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-6 overflow-y-auto">
      <div className={`${isDark ? 'bg-slate-900' : 'bg-white'} rounded-3xl p-8 max-w-4xl w-full my-8 relative`}>
        <button
          onClick={onClose}
          className={`absolute top-6 right-6 p-2 rounded-lg transition-all ${isDark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'}`}
        >
          <X size={20} />
        </button>

        <h2 className={`text-3xl font-bold mb-6 ${isDark ? 'text-white' : 'text-slate-900'}`}>
          Admin Panel
        </h2>

        <div className="flex gap-2 mb-6 border-b border-slate-700 pb-2">
          {['skills', 'projects', 'visibility'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                activeTab === tab
                  ? isDark
                    ? 'bg-blue-600 text-white'
                    : 'bg-blue-500 text-white'
                  : isDark
                  ? 'text-slate-400 hover:text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {activeTab === 'skills' && (
          <div>
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-slate-900'}`}>
              Manage Skills
            </h3>

            <div className="flex gap-2 mb-6">
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAddSkill()}
                className={`flex-1 px-4 py-3 rounded-xl transition-all ${
                  isDark
                    ? 'bg-slate-800 border border-slate-700 text-white'
                    : 'bg-white border border-slate-200 text-slate-900'
                } focus:outline-none focus:ring-2 focus:ring-blue-500/20`}
                placeholder="Add new skill..."
              />
              <button
                onClick={handleAddSkill}
                className="px-6 py-3 rounded-xl font-medium bg-blue-600 hover:bg-blue-500 text-white transition-all flex items-center gap-2"
              >
                <Plus size={20} />
                Add
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {skills.map((skill, index) => (
                <div
                  key={index}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                    isDark ? 'bg-slate-800' : 'bg-slate-100'
                  }`}
                >
                  <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>{skill}</span>
                  <button
                    onClick={() => handleRemoveSkill(index)}
                    className="text-red-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'projects' && (
          <div>
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-slate-900'}`}>
              Manage Projects
            </h3>

            <div className="space-y-3">
              {projects.map((project) => (
                <div
                  key={project.id}
                  className={`flex items-center justify-between p-4 rounded-xl ${
                    isDark ? 'bg-slate-800' : 'bg-slate-100'
                  }`}
                >
                  <div>
                    <p className={`font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                      {project.title}
                    </p>
                    <p className={`text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                      {project.visible ? 'Visible' : 'Hidden'}
                    </p>
                  </div>
                  <button
                    onClick={() => toggleProjectVisibility(project.id)}
                    className={`p-2 rounded-lg transition-all ${
                      project.visible
                        ? 'bg-green-600 text-white'
                        : isDark
                        ? 'bg-slate-700 text-slate-400'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {project.visible ? <Eye size={20} /> : <EyeOff size={20} />}
                  </button>
                </div>
              ))}
            </div>

            <p className={`mt-6 text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
              Note: Project data will be stored in your database. Connect to Neon to persist changes.
            </p>
          </div>
        )}

        {activeTab === 'visibility' && (
          <div>
            <h3 className={`text-xl font-bold mb-4 ${isDark ? 'text-white' : 'text-slate-900'}`}>
              Section Visibility
            </h3>

            <div className="space-y-3">
              {sections.map((section) => (
                <div
                  key={section.id}
                  className={`flex items-center justify-between p-4 rounded-xl ${
                    isDark ? 'bg-slate-800' : 'bg-slate-100'
                  }`}
                >
                  <div>
                    <p className={`font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                      {section.name}
                    </p>
                    <p className={`text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                      {section.visible ? 'Shown on page' : 'Hidden from visitors'}
                    </p>
                  </div>
                  <button
                    onClick={() => toggleSectionVisibility(section.id)}
                    className={`p-2 rounded-lg transition-all ${
                      section.visible
                        ? 'bg-green-600 text-white'
                        : isDark
                        ? 'bg-slate-700 text-slate-400'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {section.visible ? <Eye size={20} /> : <EyeOff size={20} />}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className={`mt-8 p-4 rounded-xl ${isDark ? 'bg-blue-900/20 border border-blue-800' : 'bg-blue-50 border border-blue-200'}`}>
          <p className={`text-sm ${isDark ? 'text-blue-300' : 'text-blue-800'}`}>
            <strong>Note:</strong> This admin panel is frontend-only. To persist changes, connect your Neon database and implement API endpoints.
          </p>
        </div>
      </div>
    </div>
  );
}
