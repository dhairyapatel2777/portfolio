import { useState, useEffect, useRef } from 'react';
import { Mail, Github, Linkedin, Phone, MapPin, ExternalLink, Code2, Briefcase, GraduationCap, Award, Moon, Sun, Gamepad2, User, Settings } from 'lucide-react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ScrollToPlugin } from 'gsap/ScrollToPlugin';
import { useGSAP } from '@gsap/react';
import { SnakeGame } from './components/SnakeGame';
import { MemoryGame } from './components/MemoryGame';
import { Game2048 } from './components/Game2048';
import { AuthModal } from './components/AuthModal';
import { AdminPanel } from './components/AdminPanel';

gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

type ViewMode = 'portfolio' | 'games';
type ActiveGame = 'snake' | 'memory' | '2048' | null;

interface User {
  email: string;
  role: 'user' | 'admin';
}

function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [viewMode, setViewMode] = useState<ViewMode>('portfolio');
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeGame, setActiveGame] = useState<ActiveGame>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      const currentScroll = window.scrollY;
      setScrollProgress((currentScroll / totalScroll) * 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useGSAP(() => {
    ScrollTrigger.refresh();

    const sections = gsap.utils.toArray('.scroll-section');
    sections.forEach((section: any) => {
      gsap.from(section, {
        opacity: 0,
        y: 60,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: section,
          start: 'top 85%',
          toggleActions: 'play none none none',
        }
      });
    });

    gsap.utils.toArray('.card-animate').forEach((card: any) => {
      gsap.from(card, {
        opacity: 0,
        y: 50,
        duration: 0.7,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: card,
          start: 'top 90%',
          toggleActions: 'play none none none',
        }
      });
    });

    gsap.from('.hero-title', {
      opacity: 0,
      y: 40,
      duration: 1,
      ease: 'power3.out',
    });

    gsap.from('.hero-subtitle', {
      opacity: 0,
      y: 30,
      duration: 1,
      delay: 0.2,
      ease: 'power3.out',
    });

    gsap.from('.hero-social', {
      opacity: 0,
      y: 30,
      duration: 1,
      delay: 0.4,
      ease: 'power3.out',
    });

    gsap.from('.hero-cta', {
      opacity: 0,
      scale: 0.95,
      duration: 1,
      delay: 0.6,
      ease: 'power3.out',
    });
  }, { scope: containerRef, dependencies: [viewMode] });

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      gsap.to(window, {
        duration: 1.2,
        scrollTo: { y: element, offsetY: 80 },
        ease: 'power3.inOut'
      });
    }
  };

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const handleAuth = (authUser: User) => {
    setUser(authUser);
  };

  const handleLogout = () => {
    setUser(null);
    setShowAdmin(false);
  };

  const isDark = theme === 'dark';
  const isGamesMode = viewMode === 'games';

  if (isGamesMode) {
    return (
      <div ref={containerRef} className={`min-h-screen transition-colors duration-500 ${isDark ? 'bg-gradient-to-br from-slate-950 via-purple-950/30 to-slate-950 text-white' : 'bg-gradient-to-br from-white via-purple-50/30 to-white text-slate-900'}`}>
        <div
          className={`fixed top-0 left-0 h-0.5 z-50 transition-all duration-300 ${isDark ? 'bg-gradient-to-r from-purple-500 to-pink-500' : 'bg-gradient-to-r from-purple-600 to-pink-600'}`}
          style={{ width: `${scrollProgress}%` }}
        />

        <nav className={`fixed top-0 w-full z-40 transition-all duration-500 ${isDark ? 'bg-slate-950/70' : 'bg-white/70'} backdrop-blur-xl border-b ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
          <div className="max-w-7xl mx-auto px-6 lg:px-12 py-5">
            <div className="flex justify-between items-center">
              <a href="#home" className={`text-xl font-semibold tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Dhyan Patel
              </a>
              <div className="flex items-center gap-8">
                <button
                  onClick={() => setViewMode('portfolio')}
                  className={`text-sm font-medium transition-colors duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
                >
                  Portfolio
                </button>
                {user ? (
                  <>
                    <span className={`text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                      {user.email} ({user.role})
                    </span>
                    {user.role === 'admin' && (
                      <button
                        onClick={() => setShowAdmin(true)}
                        aria-label="Open admin settings"
                        className={`p-2 rounded-lg transition-all duration-300 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}
                      >
                        <Settings size={18} />
                      </button>
                    )}
                    <button
                      onClick={handleLogout}
                      className={`text-sm font-medium transition-colors duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
                    >
                      Logout
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setShowAuth(true)}
                    className={`flex items-center gap-2 text-sm font-medium transition-colors duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
                  >
                    <User size={18} />
                    Sign In
                  </button>
                )}
                <button
                  onClick={toggleTheme}
                  className={`p-2 rounded-lg transition-all duration-300 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}
                >
                  {isDark ? <Sun size={18} /> : <Moon size={18} />}
                </button>
              </div>
            </div>
          </div>
        </nav>

        <div className="pt-32 pb-20 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h1 className={`text-5xl md:text-6xl font-bold mb-4 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Game Center
              </h1>
              <p className={`text-xl ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Challenge yourself with classic games. {user ? 'Your high scores are saved!' : 'Sign in to save scores!'}
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div
                onClick={() => setActiveGame('snake')}
                className={`rounded-3xl p-8 transition-all duration-300 hover:scale-105 cursor-pointer ${isDark ? 'bg-slate-900/50 hover:bg-slate-900' : 'bg-white hover:shadow-xl'}`}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-3 rounded-xl ${isDark ? 'bg-purple-500/10' : 'bg-purple-50'}`}>
                    <Gamepad2 className={`${isDark ? 'text-purple-400' : 'text-purple-600'}`} size={32} />
                  </div>
                  <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Snake</h3>
                </div>
                <p className={`mb-6 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                  Classic snake game. Eat food, grow longer, avoid walls!
                </p>
                <button className={`w-full py-3 rounded-xl font-medium transition-all duration-300 ${isDark ? 'bg-purple-600 hover:bg-purple-500 text-white' : 'bg-purple-600 hover:bg-purple-700 text-white'}`}>
                  Play Snake
                </button>
              </div>

              <div
                onClick={() => setActiveGame('memory')}
                className={`rounded-3xl p-8 transition-all duration-300 hover:scale-105 cursor-pointer ${isDark ? 'bg-slate-900/50 hover:bg-slate-900' : 'bg-white hover:shadow-xl'}`}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-3 rounded-xl ${isDark ? 'bg-pink-500/10' : 'bg-pink-50'}`}>
                    <Gamepad2 className={`${isDark ? 'text-pink-400' : 'text-pink-600'}`} size={32} />
                  </div>
                  <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Memory</h3>
                </div>
                <p className={`mb-6 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                  Test your memory by matching pairs of cards!
                </p>
                <button className={`w-full py-3 rounded-xl font-medium transition-all duration-300 ${isDark ? 'bg-pink-600 hover:bg-pink-500 text-white' : 'bg-pink-600 hover:bg-pink-700 text-white'}`}>
                  Play Memory
                </button>
              </div>

              <div
                onClick={() => setActiveGame('2048')}
                className={`rounded-3xl p-8 transition-all duration-300 hover:scale-105 cursor-pointer ${isDark ? 'bg-slate-900/50 hover:bg-slate-900' : 'bg-white hover:shadow-xl'}`}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-3 rounded-xl ${isDark ? 'bg-blue-500/10' : 'bg-blue-50'}`}>
                    <Gamepad2 className={`${isDark ? 'text-blue-400' : 'text-blue-600'}`} size={32} />
                  </div>
                  <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>2048</h3>
                </div>
                <p className={`mb-6 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                  Combine tiles to reach 2048. Think strategically!
                </p>
                <button className={`w-full py-3 rounded-xl font-medium transition-all duration-300 ${isDark ? 'bg-blue-600 hover:bg-blue-500 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}>
                  Play 2048
                </button>
              </div>
            </div>

            <div className={`mt-16 rounded-3xl p-8 ${isDark ? 'bg-slate-900/50' : 'bg-white'}`}>
              <h2 className={`text-3xl font-bold mb-6 ${isDark ? 'text-white' : 'text-slate-900'}`}>Leaderboard</h2>
              <p className={`${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                {user
                  ? 'Your high scores will be displayed here once you play games!'
                  : 'Sign in to save your high scores and compete with others!'}
              </p>
            </div>
          </div>
        </div>

        {activeGame === 'snake' && <SnakeGame onClose={() => setActiveGame(null)} isDark={isDark} />}
        {activeGame === 'memory' && <MemoryGame onClose={() => setActiveGame(null)} isDark={isDark} />}
        {activeGame === '2048' && <Game2048 onClose={() => setActiveGame(null)} isDark={isDark} />}
        {showAuth && <AuthModal onClose={() => setShowAuth(false)} onAuth={handleAuth} isDark={isDark} />}
        {showAdmin && <AdminPanel onClose={() => setShowAdmin(false)} isDark={isDark} />}
      </div>
    );
  }

  return (
    <div ref={containerRef} className={`min-h-screen transition-colors duration-500 ${isDark ? 'bg-slate-950 text-white' : 'bg-white text-slate-900'}`}>
      <div
        className={`fixed top-0 left-0 h-0.5 z-50 transition-all duration-300 ${isDark ? 'bg-gradient-to-r from-blue-500 to-violet-500' : 'bg-gradient-to-r from-blue-600 to-indigo-600'}`}
        style={{ width: `${scrollProgress}%` }}
      />

      <nav className={`fixed top-0 w-full z-40 transition-all duration-500 ${isDark ? 'bg-slate-950/70' : 'bg-white/70'} backdrop-blur-xl border-b ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-5">
          <div className="flex justify-between items-center">
            <a href="#home" className={`text-xl font-semibold tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
              Dhyan Patel
            </a>
            <div className="flex items-center gap-8">
              {['About', 'Projects', 'Skills', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className={`text-sm font-medium transition-colors duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
                >
                  {item}
                </button>
              ))}
              <button
                onClick={() => setViewMode('games')}
                className={`flex items-center gap-2 text-sm font-medium transition-colors duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
              >
                <Gamepad2 size={18} />
                Games
              </button>
              {user ? (
                <>
                  {user.role === 'admin' && (
                    <button
                      onClick={() => setShowAdmin(true)}
                      aria-label="Open admin settings"
                      className={`p-2 rounded-lg transition-all duration-300 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}
                    >
                      <Settings size={18} />
                    </button>
                  )}
                  <button
                    onClick={handleLogout}
                    className={`text-sm font-medium transition-colors duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
                  >
                    Logout
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setShowAuth(true)}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
                >
                  <User size={18} />
                  Sign In
                </button>
              )}
              <button
                onClick={toggleTheme}
                className={`p-2 rounded-lg transition-all duration-300 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}
              >
                {isDark ? <Sun size={18} /> : <Moon size={18} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className={`orb orb-1 ${isDark ? 'bg-blue-500/20' : 'bg-blue-400/25'}`}></div>
          <div className={`orb orb-2 ${isDark ? 'bg-violet-500/20' : 'bg-indigo-400/25'}`}></div>
          <div className={`orb orb-3 ${isDark ? 'bg-cyan-500/15' : 'bg-cyan-400/20'}`}></div>
        </div>

        <div className="relative z-10 text-center px-6 max-w-5xl mx-auto pt-20">
          <h1 className={`hero-title text-6xl md:text-8xl font-bold mb-6 tracking-tight leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Dhyan Patel
          </h1>

          <p className={`hero-subtitle text-xl md:text-2xl mb-6 max-w-3xl mx-auto leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
            Full-Stack Developer crafting exceptional digital experiences with modern web technologies
          </p>

          <div className="hero-social flex gap-6 justify-center mb-16">
            <a href="https://github.com/pateldhyan1668" target="_blank" rel="noopener noreferrer"
              className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}>
              <Github size={24} />
            </a>
            <a href="https://linkedin.com/in/dhyan-patel-cs" target="_blank" rel="noopener noreferrer"
              className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}>
              <Linkedin size={24} />
            </a>
            <a href="mailto:dhyanpatel.1668@gmail.com"
              className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}>
              <Mail size={24} />
            </a>
          </div>

          <button
            onClick={() => scrollToSection('about')}
            className={`hero-cta inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all duration-300 hover:scale-105 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-900 text-white hover:bg-slate-800'}`}
          >
            View My Work
          </button>
        </div>
      </section>

      <section id="about" className={`scroll-section py-32 px-6 relative`}>
        <div className="max-w-6xl mx-auto">
          <h2 className={`text-4xl md:text-5xl font-bold mb-20 text-center ${isDark ? 'text-white' : 'text-slate-900'}`}>
            About Me
          </h2>

          <div className="space-y-8">
            <div className="card-animate">
              <div className={`rounded-3xl p-10 transition-all duration-500 hover:shadow-xl ${isDark ? 'bg-slate-900/50 hover:bg-slate-900' : 'bg-white/80 backdrop-blur-sm hover:shadow-2xl'}`}>
                <div className="flex items-start gap-6 mb-6">
                  <div className={`p-4 rounded-2xl ${isDark ? 'bg-blue-500/10' : 'bg-blue-50'}`}>
                    <GraduationCap className={`${isDark ? 'text-blue-400' : 'text-blue-600'}`} size={32} />
                  </div>
                  <div className="flex-1">
                    <h3 className={`text-2xl font-bold mb-3 ${isDark ? 'text-white' : 'text-slate-900'}`}>Education</h3>
                    <h4 className={`text-xl font-semibold mb-2 ${isDark ? 'text-blue-400' : 'text-blue-600'}`}>McMaster University</h4>
                    <p className={`text-lg mb-3 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>Honours Bachelor of Computer Science</p>
                    <p className={`leading-relaxed ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                      Hi, I'm Dhyan. I love building modern, impactful, and well-designed digital solutions — whether it's a web application, a software project, or a creative experiment that blends technology and design.

                      I'm passionate about learning new tools, exploring innovative ideas, and turning concepts into practical results. I approach every project with curiosity, attention to detail, and a focus on delivering clean, efficient, and meaningful work.

                      Beyond academics, I enjoy collaborating with others, improving my technical and problem-solving skills, and continuously growing as a developer and individual. My goal is to build technology that not only works well but makes a real difference.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="projects" className={`scroll-section py-32 px-6 relative`}>
        <div className="max-w-6xl mx-auto">
          <h2 className={`text-4xl md:text-5xl font-bold mb-20 text-center ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Featured Projects
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="card-animate">
              <div className={`rounded-3xl p-8 transition-all duration-500 hover:shadow-2xl h-full ${isDark ? 'bg-slate-900/70 hover:bg-slate-900' : 'bg-white/80 backdrop-blur-sm hover:bg-white hover:shadow-xl'}`}>
                <div className="flex items-center gap-3 mb-6">
                  <Code2 className={`${isDark ? 'text-blue-400' : 'text-blue-600'}`} size={28} />
                  <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Online Banking Program</h3>
                </div>

                <div className="flex gap-2 mb-6 flex-wrap">
                  {['Python', 'Flask', 'PBKDF2', 'App'].map((tech) => (
                    <span key={tech} className={`px-4 py-2 rounded-full text-sm font-medium ${isDark ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-blue-50 text-blue-700 border border-blue-200'}`}>
                      {tech}
                    </span>
                  ))}
                </div>

                <p className={`text-sm mb-6 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                  April 2025 — September 2025
                </p>

                <ul className={`space-y-3 text-sm mb-8 leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                  <li>• Developed a full-featured command-line banking system with secure user authentication using PBKDF2-SHA256</li>
                  <li>• Designed normalized SQLite schema with users, accounts, and transactions tables, enabling accurate financial tracking</li>
                  <li>• Implemented core banking operations — registration, deposits, withdrawals, balance info, statements, and tax estimation</li>
                  <li>• Ensured data integrity through strict input validation, permission checks, and precise integer-based currency handling</li>
                </ul>

                <a href="https://github.com/pateldhyan1668" target="_blank" rel="noopener noreferrer"
                  className={`inline-flex items-center gap-2 font-medium transition-colors ${isDark ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'}`}>
                  View Project <ExternalLink size={16} />
                </a>
              </div>
            </div>

            <div className="card-animate">
              <div className={`rounded-3xl p-8 transition-all duration-500 hover:shadow-2xl h-full ${isDark ? 'bg-slate-900/70 hover:bg-slate-900' : 'bg-white/80 backdrop-blur-sm hover:bg-white hover:shadow-xl'}`}>
                <div className="flex items-center gap-3 mb-6">
                  <Code2 className={`${isDark ? 'text-indigo-400' : 'text-indigo-600'}`} size={28} />
                  <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>2048 Puzzle Game</h3>
                </div>

                <div className="flex gap-2 mb-6 flex-wrap">
                  {['C', 'SDL2', 'Algorithms'].map((tech) => (
                    <span key={tech} className={`px-4 py-2 rounded-full text-sm font-medium ${isDark ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' : 'bg-indigo-50 text-indigo-700 border border-indigo-200'}`}>
                      {tech}
                    </span>
                  ))}
                </div>

                <p className={`text-sm mb-6 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                  September 2024 — January 2025
                </p>

                <ul className={`space-y-3 text-sm mb-8 leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                  <li>• Engineered complete 2048 game in C with SDL2, implementing tile sliding and merge detection algorithms</li>
                  <li>• Built custom bitmap font rendering system with dynamic scaling and anti-aliasing</li>
                  <li>• Developed smooth animations using cubic easing functions for polished UI</li>
                  <li>• Designed cross-platform Makefile build system for portability</li>
                </ul>

                <a href="https://github.com/pateldhyan1668" target="_blank" rel="noopener noreferrer"
                  className={`inline-flex items-center gap-2 font-medium transition-colors ${isDark ? 'text-indigo-400 hover:text-indigo-300' : 'text-indigo-600 hover:text-indigo-700'}`}>
                  View Project <ExternalLink size={16} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="skills" className={`scroll-section py-32 px-6 relative`}>
        <div className="max-w-6xl mx-auto">
          <h2 className={`text-4xl md:text-5xl font-bold mb-20 text-center ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Technical Skills
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: 'Frontend Development',
                skills: ['React', 'Next.js', 'Redux Toolkit', 'TypeScript', 'JavaScript', 'Ant Design', 'Tailwind CSS', 'Framer Motion', 'SCSS', 'HTML', 'CSS', 'GSAP'],
              },
              {
                title: 'Backend & Database',
                skills: ['Flask', 'FastAPI', 'NestJS', 'Node.js', 'REST APIs', 'PostgreSQL', 'SQLAlchemy', 'JWT', 'Axios', 'AWS S3', 'OpenAI API'],
              },
              {
                title: 'Programming & CS Fundamentals',
                skills: ['Python', 'C', 'Java', 'Data Structures', 'Algorithms', 'OOP', 'SDL2', 'Real-time Systems', 'Memory Management'],
              },
              {
                title: 'Development Tools & Practices',
                skills: ['GitHub', 'npm', 'Postman', 'Make', 'Agile/Scrum', 'Performance Optimization', 'Cross-platform Development', 'Code Review'],
              }
            ].map((category) => (
              <div key={category.title} className="card-animate">
                <div className={`rounded-3xl p-8 transition-all duration-500 hover:shadow-xl h-full ${isDark ? 'bg-slate-900/50 hover:shadow-2xl' : 'bg-white/80 backdrop-blur-sm hover:shadow-2xl'}`}>
                  <h3 className={`text-xl font-bold mb-6 ${isDark ? 'text-white' : 'text-slate-900'}`}>{category.title}</h3>
                  <div className="flex flex-wrap gap-2">
                    {category.skills.map((skill) => (
                      <span
                        key={skill}
                        className={`px-4 py-2 rounded-lg text-sm transition-all duration-300 hover:scale-105 ${isDark ? 'bg-slate-800 text-slate-300 hover:bg-slate-700' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className={`scroll-section py-32 px-6 relative`}>
        <div className="max-w-5xl mx-auto">
          <h2 className={`text-4xl md:text-5xl font-bold mb-20 text-center ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Get In Touch
          </h2>

          <div className="grid md:grid-cols-5 gap-12">
            <div className="md:col-span-2 card-animate">
              <h3 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-slate-900'}`}>Let's Connect</h3>
              <p className={`mb-10 leading-relaxed ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                Open to discussing new opportunities, collaborations, and innovative projects. Feel free to reach out.
              </p>

              <div className="space-y-5">
                <a href="mailto:dhyanpatel.1668@gmail.com"
                  className={`flex items-center gap-4 group transition-all duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-700 hover:text-slate-900'}`}>
                  <div className={`p-3 rounded-xl transition-all duration-300 ${isDark ? 'bg-slate-800 group-hover:bg-slate-700' : 'bg-slate-100 group-hover:bg-slate-200'}`}>
                    <Mail size={20} />
                  </div>
                  <span className="text-sm">dhyanpatel.1668@gmail.com</span>
                </a>

                <a href="tel:5198060079"
                  className={`flex items-center gap-4 group transition-all duration-300 ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-700 hover:text-slate-900'}`}>
                  <div className={`p-3 rounded-xl transition-all duration-300 ${isDark ? 'bg-slate-800 group-hover:bg-slate-700' : 'bg-slate-100 group-hover:bg-slate-200'}`}>
                    <Phone size={20} />
                  </div>
                  <span className="text-sm">437-879-9126</span>
                </a>

                <div className={`flex items-center gap-4 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                  <div className={`p-3 rounded-xl ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}>
                    <MapPin size={20} />
                  </div>
                  <span className="text-sm">Hamilton, ON, Canada</span>
                </div>
              </div>

              <div className="flex gap-4 mt-10">
                <a href="https://github.com/pateldhyan1668" target="_blank" rel="noopener noreferrer"
                  className={`p-3 rounded-xl transition-all duration-300 hover:scale-110 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}>
                  <Github size={20} />
                </a>
                <a href="https://linkedin.com/in/dhyan-patel-cs" target="_blank" rel="noopener noreferrer"
                  className={`p-3 rounded-xl transition-all duration-300 hover:scale-110 ${isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'}`}>
                  <Linkedin size={20} />
                </a>
              </div>
            </div>

            <div className="md:col-span-3 card-animate">
              <p className={`text-center text-lg ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                Contact form removed - will be connected when you integrate Neon DB
              </p>
            </div>
          </div>
        </div>
      </section>

      <footer className={`py-10 px-6 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
        <div className={`max-w-6xl mx-auto text-center text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
          <p>&copy; 2025 Dhyan Patel. All rights reserved.</p>
        </div>
      </footer>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} onAuth={handleAuth} isDark={isDark} />}
      {showAdmin && <AdminPanel onClose={() => setShowAdmin(false)} isDark={isDark} />}
    </div>
  );
}

export default App;
