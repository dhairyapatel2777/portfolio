import { useState, useEffect } from 'react';
import { RotateCcw } from 'lucide-react';

type Card = {
  id: number;
  value: string;
  isFlipped: boolean;
  isMatched: boolean;
};

const CARD_VALUES = ['🎮', '🎯', '🎨', '🎭', '🎪', '🎸', '🎺', '🎻'];

export function MemoryGame({ onClose, isDark }: { onClose: () => void; isDark: boolean }) {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [matches, setMatches] = useState(0);
  const [isWon, setIsWon] = useState(false);

  const initializeGame = () => {
    const shuffled = [...CARD_VALUES, ...CARD_VALUES]
      .sort(() => Math.random() - 0.5)
      .map((value, index) => ({
        id: index,
        value,
        isFlipped: false,
        isMatched: false,
      }));
    setCards(shuffled);
    setFlippedCards([]);
    setMoves(0);
    setMatches(0);
    setIsWon(false);
  };

  useEffect(() => {
    initializeGame();
  }, []);

  useEffect(() => {
    if (matches === CARD_VALUES.length) {
      setIsWon(true);
    }
  }, [matches]);

  const handleCardClick = (id: number) => {
    if (flippedCards.length === 2 || cards[id].isFlipped || cards[id].isMatched) {
      return;
    }

    const newCards = [...cards];
    newCards[id].isFlipped = true;
    setCards(newCards);

    const newFlippedCards = [...flippedCards, id];
    setFlippedCards(newFlippedCards);

    if (newFlippedCards.length === 2) {
      setMoves(moves + 1);
      const [firstId, secondId] = newFlippedCards;

      if (cards[firstId].value === cards[secondId].value) {
        newCards[firstId].isMatched = true;
        newCards[secondId].isMatched = true;
        setCards(newCards);
        setMatches(matches + 1);
        setFlippedCards([]);
      } else {
        setTimeout(() => {
          const resetCards = [...cards];
          resetCards[firstId].isFlipped = false;
          resetCards[secondId].isFlipped = false;
          setCards(resetCards);
          setFlippedCards([]);
        }, 1000);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-6">
      <div className={`${isDark ? 'bg-slate-900' : 'bg-white'} rounded-3xl p-8 max-w-2xl w-full`}>
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>Memory Game</h2>
            <p className={`text-lg mt-2 ${isDark ? 'text-pink-400' : 'text-pink-600'}`}>
              Moves: {moves} | Matches: {matches}/{CARD_VALUES.length}
            </p>
          </div>
          <button
            onClick={onClose}
            className={`px-4 py-2 rounded-xl font-medium transition-all ${isDark ? 'bg-slate-800 hover:bg-slate-700 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-900'}`}
          >
            Close
          </button>
        </div>

        <div className="grid grid-cols-4 gap-4 mb-6">
          {cards.map((card) => (
            <button
              key={card.id}
              onClick={() => handleCardClick(card.id)}
              className={`aspect-square rounded-2xl text-4xl font-bold transition-all duration-300 transform ${card.isFlipped || card.isMatched
                  ? isDark
                    ? 'bg-gradient-to-br from-pink-600 to-pink-500 text-white scale-100'
                    : 'bg-gradient-to-br from-pink-500 to-pink-400 text-white scale-100'
                  : isDark
                    ? 'bg-slate-800 hover:bg-slate-700 scale-95'
                    : 'bg-slate-100 hover:bg-slate-200 scale-95'
                } ${card.isMatched ? 'opacity-60' : ''}`}
              disabled={card.isFlipped || card.isMatched}
            >
              {card.isFlipped || card.isMatched ? card.value : '?'}
            </button>
          ))}
        </div>

        {isWon && (
          <div className="text-center mb-6">
            <p className={`text-2xl font-bold mb-4 ${isDark ? 'text-green-400' : 'text-green-600'}`}>
              You Won! 🎉
            </p>
            <p className={`text-lg mb-4 ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
              Completed in {moves} moves
            </p>
            <button
              onClick={initializeGame}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-medium bg-pink-600 hover:bg-pink-500 text-white transition-all"
            >
              <RotateCcw size={20} />
              Play Again
            </button>
          </div>
        )}

        <div className={`text-center text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
          <p>Click cards to flip them and find matching pairs</p>
        </div>
      </div>
    </div>
  );
}